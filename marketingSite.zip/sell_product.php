<html>
    <head>
    
        <script type='text/javascript'>
        
            function preview_image(event)
            {
                var reader = new FileReader();
                reader.onload = function ()
                {
                    var output = document.getElementById('output_image');
                    output.src = reader.result;
                };
                reader.readAsDataURL(event.target.files[0]);
            }
            
            function preview_image2(event)
            {
                var reader = new FileReader();
                reader.onload = function ()
                {
                    var output = document.getElementById('output_image2');
                    output.src = reader.result;
                };
                reader.readAsDataURL(event.target.files[0]);
            }
            
            function preview_image3(event)
            {
                var reader = new FileReader();
                reader.onload = function ()
                {
                    var output = document.getElementById('output_image3');
                    output.src = reader.result;
                };
                reader.readAsDataURL(event.target.files[0]);
            }
            
            
            
          
        </script> 
        
        <meta charset="UTF-8">
        <link rel="stylesheet" href="Resource/CssHomePro/Home_Programmer_css.css" type="text/css"/>
        <link rel="stylesheet" href="Resource/CssHomePro/cssAlljob.css" type="text/css"/>
        <link rel="stylesheet" href="Resource/css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="Resource/css/bootstrap.css" type="text/css">
         <link rel="stylesheet" href="Resource/css/styleJO.css">
          <link rel="stylesheet" href="Resource/css/jsJOSEPH.css">
        <title> Upload Product </title>
    </head>
    <body>
        
  
        
       
 
        
       
        <header>
         <h4>For Help :01554171628 </h4>
      
       
        </header> 
        
        
        
        
        <div class="contents_gallary">


             <ul>
                
              <li style="margin-left: 10%"><a href="gramophone.php">Gramophone</a></li>
                <li><a href="telephone.php">Telephone</a></li>
                <li><a href="camera.php">Camera</a></li>
                 <li><a href="light.php">Lamps</a></li>
              
                 <li><a href="books.php"> Books</a></li>
                 <li><a href="woods.php">Furniture</a></li>
                 <li><a href="coins.php">Coins</a></li>
                 <li><a href="watches.php">watches</a></li>
                 <li><a href="painting.php">Painting</a></li>
                 <li><a href="tools.php">Tools</a></li>
                

            </ul>
         </div>
           
        
        
        
        
       
         <form method="POST" enctype="multipart/form-data" action="sell_product">
            <table>
                <tr>
                <td>
              
                <img src="Resource/images/logo_n.png" id="output_image" width="150px" height="150px" alt="a7a where the fucking photo" />
                
                </td>
                          
                            <td>
                            
                            <img src="Resource/images/logo_n.png" id="output_image2" width="150px" height="150px" alt="a7a where the fucking photo" />
                        
                         </td>
                     
                     <td>
                            
                            <img src="Resource/images/logo_n.png" id="output_image3" width="150px" height="150px" alt="a7a where the fucking photo" />
                        
                         </td>
                         
                         
                     
                </tr>
                 <tr>
                     <td> <input  type="file" name="image" accept="image/*" onchange="preview_image(event)" /> </td>
                     
                     <td> <input " type="file" name="image2" accept="image/*" onchange="preview_image2(event)" /> </td>
                     
                     <td> <input  type="file" name="image3" accept="image/*" onchange="preview_image3(event)" /> </td>
                     
            
                     
                </tr>
            </table>
                
               
             
          
                
                
            <table>
                 <tr>
                     <td> <input style="margin-left:30px; margin-top: 20px;" type="text" name="name" placeholder="item name اسم المنتج" /> </td>
                     <td> <input style="margin-left:30px; margin-top: 20px;" type="text" name="age" placeholder="age العمر" /> </td>  
                     <td> <input style="margin-left:30px; margin-top: 20px;" type="text" name="price" placeholder="Price السعر" /> </td>
                       <td> <select style="margin-left:30px; margin-top: 20px;" name="video">
                       <option>product type</option>
                       <option>gramophone</option>
                       <option>telephone</option>
                       <option>camera</option>
                       <option>light unit</option>
                       <option>Books</option>
                       <option>furniture</option>
                       <option>coins</option>
                       <option>watches</option>
                       <option>panting</option>
                       <option>tools</option>
                       </select>  </td>
                   
                       
                </tr>
                
                <tr>
                     <td> <input required="required" style="margin-left:30px; margin-top: 20px;" type="text"  name="store_address" placeholder="Your address العنوان" /> </td>
                     
                     <td> <input required="required" style="margin-left:30px; margin-top: 20px;" type="text"  name="store_phone" placeholder="Your Number رقم التلفون"/> </td>
                     <td> <input required="required" style="margin-left:30px; margin-top: 20px;" type="text"  name="email" placeholder="E-mail الايميل " /> </td>
                     <td> <input style="margin-left:30px; margin-top: 20px;" type="text" name="information" placeholder="Information" /> </td>  
                     
                     <td>  <input class="btn-primary" type="submit" name="submit" value="Sell now" style="margin-left:50px; margin-top: 20px;" /> </td>
                </tr>
                
                
            </table> 
            
                 
                 
                
                 

                 
                 
                 
            </form>      
            <?php
           
            
             if(isset($_POST['submit']) and $_POST['submit']=="Sell now"){
      
      
      include 'infoConnect.php';
       $con=mysqli_connect($host,$user,$password,$dataname);
        
            
         // basic file info
         $email=$_SESSION['email'];
        $name=$_POST['name'];
        $store_phone=$_POST['store_phone'];
        $store_address=$_POST['store_address'];
        $age=$_POST['age'];
        $price=$_POST['price'];
        $video=$_POST['video'];
        $price=$_POST['price'];
        $information=$_POST['information'];
        $stat="not yet";

        //
            $pdf = addslashes(file_get_contents($_FILES['image']['tmp_name']));
            
            $namepdf = addslashes($_FILES['inputname']['name']);   
            
            $image2 = addslashes(file_get_contents($_FILES['image2']['tmp_name']));
            
            $imagename2 = addslashes($_FILES['inputname']['name']);   
            
            $image3 = addslashes(file_get_contents($_FILES['image3']['tmp_name']));
            
            $imagename3 = addslashes($_FILES['inputname']['name']);            
            
             
            
            $mysqli=mysqli_query($con,"insert into  items_file_jo_lhoda(item_name,age,price,store_address,store_phone,video_link,email,information,image_name,image_file,image_file2,image_file3,status)"
                    . "values('$name','$age','$price','$store_address','$store_phone','$video','$email','$information','$namepdf','$pdf','$image2','$image3','$stat')");
                 
    
            if($mysqli){
        
                 echo '<script> window.open("thank_you.php","_self")</script>' ;
         
            }else{
                
                echo '<h2>call 01149239042</h2>'. mysqli_error();
                
            }    
           
            		
        
        
        
        
             }
            ?>
            
           
           
           
           
           
            
           
           
            
            
              <footer>

             <p class="footer_gallary_p">Copyright reserved - Joseph A Mork</p>
            
        </footer>

    </body>
</html>
