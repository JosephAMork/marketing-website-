<?php
session_start();
if(!isset($_SESSION['en_email'])){
    include 'god.php';
    die();
}

?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="Resource/CssHomePro/Home_Programmer_css.css" type="text/css"/>
        <link rel="stylesheet" href="Resource/CssHomePro/cssAlljob.css" type="text/css"/>
        <link rel="stylesheet" href="Resource/css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="Resource/css/bootstrap.css" type="text/css">
         <link rel="stylesheet" href="Resource/css/styleJO.css">
         <link rel="stylesheet" href="Resource/css/jsJOSEPH.css">
       
        <title>  </title>
        
        
        
        <style>
input[type=text], select, textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    margin-top: 6px;
    margin-bottom: 16px;
    resize: vertical;
}

input[type=submit] {
    background-color: #4CAF50;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #45a049;
}

.container {
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
}
</style>
    </head>
    <body>
       
         <h1> <img class="kk" src="Resource/images/antika.png" width="80%" height="200" alt="logo"/> </h1>
  
       

       
         
        <header>
       
      
       
        </header> 
      
        <div class="contents_gallary">


             <ul>
                
             <li style="margin-left: 10%"><a href="addnewitem_god.php">Add Items</a></li>
                
                <li><a href="All_items_god.php">All Items</a></li>
                 <li><a href="has_sold_all.php">Has Sold</a></li>
                 <li><a href="#">|</a></li>
                 <li><a href="add_auction.php"> Add Auction</a></li>
                 <li><a href="special_orders_all.php">Special Orders </a></li>
                 
                 <!--  <li><a href="coins.php">Coins</a></li>
                 <li><a href="watches.php">watches</a></li>
                 <li><a href="panting.php">Panting</a></li>
                 <li><a href="tools.php">Tools</a></li>
                -->


            </ul>
         </div>
  
  
  
  


<div class="container" style="margin-left:10%;">
  
    
    <iframe width="800" height="345" src="https://www.youtube.com/watch?v=2ort_n1DScg">
</iframe>
   

 
</div>

  
  
  
  
      
        <footer>

             <p class="footer_gallary_p">Copyright reserved - Joseph A Mork</p>
            
        </footer>

    </body>
</html>