<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="Resource/CssHomePro/Home_Programmer_css.css" type="text/css"/>
        <link rel="stylesheet" href="Resource/CssHomePro/cssAlljob.css" type="text/css"/>
        <link rel="stylesheet" href="Resource/css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="Resource/css/bootstrap.css" type="text/css">
         <link rel="stylesheet" href="Resource/css/styleJO.css">
         <link rel="stylesheet" href="Resource/css/jsJOSEPH.css">
         <link rel="stylesheet" href="Resource/CssHomePro/search.css" type="text/css"/>
        <title> antika camera </title>
        
        
        
        <script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

        
    </head>
    <body>
       
         <h1> <img class="kk" src="Resource/images/antika.png" width="30%" height="120" alt="logo"/> </h1>
     
   <form action="camera" method="POST">
     <input required="required" style="margin-top: 10px;" class="searchpro" size="40" type="text" name="search_text" placeholder="  Search here " />
            <input class="btn-danger" type="submit" name="submit" value="Search" />
     </form>
        


<div id="google_translate_element"></div>

       
       <!--    
        <header>
       
      
        </div>
        </header> 
       -->
        <div class="contents_gallary">


             <ul>
                
              <li style="margin-left: 10%"><a href="gramophone.php">Gramophone</a></li>
                <li><a href="telephone.php">Telephone</a></li>
                <li><a href="camera.php">Camera</a></li>
                 <li><a href="light.php">Lamps</a></li>
                
                 <li><a href="books.php"> Books</a></li>
                 <li><a href="woods.php">Furniture</a></li>
                 <li><a href="coins.php">Coins</a></li>
                 <li><a href="watches.php">watches</a></li>
                 <li><a href="panting.php">Painting</a></li>
                 <li><a href="tools.php">Tools</a></li>
                

            </ul>
         </div>
  
  
   <form action="camera" method="POST">
      
            
           
            <ul>          
                  <?php
                  
                  if(isset($_POST['submit']) and $_POST['submit']=="Search"){
                     
         include 'infoConnect.php';
        
        $con=mysqli_connect($host,$user,$password,$dataname);
        
        $value=$_POST['search_text'];
        
       $stat="not yet";
        
        $result=  mysqli_query($con,"select * from items_file_jo_lhoda where item_name like '%$value%' AND status='$stat'");
        
        if(mysqli_num_rows($result)>0){
                        while($row = mysqli_fetch_assoc($result))  
                {  
              $item_id=$row['id_item'];
                $item_name=$row['item_name'];
                $price=$row['price'];
                $age=$row['age'];
                $address=$row['store_address'];
               
                
                                ?>
                                                      
                     <li style="margin-right: 10px; margin-bottom: 10px;">
                
<div class="card">
    <?php
               echo ' <img src="data:image/jpeg;base64,'.base64_encode($row['image_file'] ).'" height="250" width="250" class="img-thumnail" /> ';
   echo"
    <h3 style='color: #007bff;'>$item_name </h3>
    <p style='color: #bd2130;'> Price : $price </p>
  <p style='color: #007bff;'> Age : $age </p>
  <div style='margin: 24px 0;'>
 
      
      <h6 style='color: #007bff;'>$address</h6> 
      
      <button><a href='buy_now.php?item_id=$item_id'> Details  </a></button>
      
      ";
      
      }   // while end 
      
      
      
      } // end of if 
      
      
      }  // search submit end 
      
      ?>

                     
                     
                     
                     
                     
                     
                     
                 

                    
       <?php  
       
       
         include 'infoConnect.php';
        
        $con=mysqli_connect($host,$user,$password,$dataname);
        $status="not yet";
        $type="camera";   
        $result=  mysqli_query($con,"select * from items_file_jo_lhoda where status='$status' AND video_link='$type'");
        
        if(mysqli_num_rows($result)>0){
                        while($row = mysqli_fetch_assoc($result))  
                {  
              $item_id=$row['id_item'];
                $item_name=$row['item_name'];
                $price=$row['price'];
                $age=$row['age'];
                $address=$row['store_address'];
               
                
                                ?>
                                                      
                     <li style="margin-right: 10px; margin-bottom: 10px;">
                
<div class="card">
    <?php
               echo ' <img src="data:image/jpeg;base64,'.base64_encode($row['image_file'] ).'" height="250" width="250" class="img-thumnail" /> ';
   echo"
    <h3 style='color: #007bff;'>$item_name </h3>
    <p style='color: #bd2130;'> Price : $price </p>
  <p style='color: #007bff;'> Age : $age </p>
  <div style='margin: 24px 0;'>
 
      
      <h6 style='color: #007bff;'>$address</h6> 
      
      <button><a href='buy_now.php?item_id=$item_id'> Details  </a></button>
      
      ";
      
      
      } // end of while
      
      
      } // end of if 
      
      ?>
      
      

</div>      
            </li>
            

            
          
             </ul>
                        
  </form>
  
  
  

        <footer>

             <p class="footer_gallary_p">Copyright reserved - Joseph A Mork</p>
            
        </footer>

    </body>
</html>