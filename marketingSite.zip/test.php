<?php

//   

$plaintext = 'sjkjhkj';
$plaintext2='skjhbmk';
$omtokiss = '3L';
$method = 'aes-256-cbc';

// Must be exact 32 chars (256 bit)
$omtokiss = substr(hash('sha256', $omtokiss, true), 0, 32);
echo "Password:" . $omtokiss . "\n";

// IV must be exact 16 chars (128 bit)
$iv = chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0);

// av3DYGLkwBsErphcyYp+imUW4QKs19hUnFyyYcXwURU=
$encrypted = base64_encode(openssl_encrypt($plaintext, $method, $omtokiss, OPENSSL_RAW_DATA, $iv));

$encrypted2 = base64_encode(openssl_encrypt($plaintext2, $method, $omtokiss, OPENSSL_RAW_DATA, $iv));


// My secret message 1234
$decrypted = openssl_decrypt(base64_decode($plaintext), $method, $omtokiss, OPENSSL_RAW_DATA, $iv);


$decrypted2 = openssl_decrypt(base64_decode($plaintext2), $method, $omtokiss, OPENSSL_RAW_DATA, $iv);


//echo 'plaintext=' . $plaintext . "\n";
//echo 'cipher=' . $method . "\n";
echo 'encrypted to: ' . $encrypted . "\n";

echo 'encrypted to: ' . $encrypted2 . "\n";

echo 'decrypted to: ' . $decrypted . "\n\n";

echo 'decrypted to: ' . $decrypted2 . "\n\n";


?>