<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="Resource/CssHomePro/Home_Programmer_css.css" type="text/css"/>
        <link rel="stylesheet" href="Resource/CssHomePro/cssAlljob.css" type="text/css"/>
        <link rel="stylesheet" href="Resource/css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="Resource/css/bootstrap.css" type="text/css">
         <link rel="stylesheet" href="Resource/css/styleJO.css">
         <link rel="stylesheet" href="Resource/css/jsJOSEPH.css">
        <title> antika </title>
        
        
        <script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

        
    </head>
    <body>
       
       <!--
       
        <h1> <img class="kk" src="Resource/images/logosite.png" width="80%" height="200" alt="logo"/> </h1>
     -->
  
       
<div id="google_translate_element"></div>


       
       <!--    
        <header>
       
      
        </div>
        </header> 
       -->
        <div class="contents_gallary">


             <ul>
                
               <li style="margin-left: 10%"><a href="gramophone.php">Gramophone</a></li>
                <li><a href="telephone.php">Telephone</a></li>
                <li><a href="camera.php">Camera</a></li>
                 <li><a href="light.php">Lamps</a></li>
               
                 <li><a href="books.php"> Books</a></li>
                 <li><a href="woods.php">Furniture</a></li>
                 <li><a href="coins.php">Coins</a></li>
                 <li><a href="watches.php">watches</a></li>
                 <li><a href="panting.php">Painting</a></li>
                 <li><a href="tools.php">Tools</a></li>
                


            </ul>
         </div>
  
  
       
      <?php  
      
      if(isset($_GET['item_id'])){
      
      include'infoConnect.php';
      
      $p_id=$_GET['item_id'];
      
      $con=mysqli_connect($host,$user,$password,$dataname);
      
     
        $result=  mysqli_query($con,"select * from items_file_jo_lhoda where id_item='$p_id'");
        
        if(mysqli_num_rows($result)==1){
                        while($row = mysqli_fetch_assoc($result))  
                {  
                     
               $item_id=$row['id_item'];
                $item_name=$row['item_name'];
                $price=$row['price'];
                $age=$row['age'];
                $address=$row['store_address'];
                $item_info=$row['information'];
                $item_type=$row['video_link'];
  
  
  ?>
  
   <form action="buy_now" method="POST" >
   
  <input type="text"  name="id_item_a" value="<?php echo "$item_id";?>"style="color:#FFFFFF; border-color:#FFFFFF"/>
  
  
  
  <?php 
       echo "
       <table>
    <tr>
    <td> <h4 style='color: #007bff;'>Name : $item_name </h4>  </td>
 
   <td> <p  style='color: #bd2130;'> Price : $price EG</p>  </td>
  <td> <p style='color: #007bff;'> Age : $age </p>  </td>
  <td> <h6 style='color: #007bff;'>Type :$item_type</h6>    </td>
  </tr>
  
  <tr>
  <td> <h6 style='color: #007bff;'>Address : $address</h6> </td>
  <td> <h6 style='color: #007bff;'>Information : $item_info</h6>  </td> 

  
  
     </tr>
     
      
   
</table>
  ";  
  
  ?>
  
 
 
  <table>
  <th>
  <tr>
  <td>
  
  <?php

echo '<img  src="data:image/jpeg;base64,'.base64_encode($row['image_file'] ).'" height="230" width="450" />';
  ?>
  
  </td>
  
  <td>
  
  <?php echo'<img src="data:image/jpeg;base64,'.base64_encode($row['image_file2']).' " height="230" width="450" />'  ?>
  
  </td>
  
  <td> 
  
  <?php   echo'<img src="data:image/jpeg;base64,'.base64_encode($row['image_file3']).' " height="230" width="450" />' ?>
  
  </td> 
  
  
  
  </tr>
  </th>

  </table>
 
   <?php
   
  }
  } 
  
  
  
    }
    ?>
 
  <div style="background-color:#ddd;margin-top:15px;">
  
  
 
  
  <table>
  
 <th>
  <tr>
   <td>
   <input type="text" required="required" name="c_phone" placeholder="Your phone" /> <input class="btn-primary" type="submit" name="submit" style="margin-left:10px;" value="buy it now"/> 

  </td>
  
   <td>
 <!--
  <b style="margin-right:30px;margin-left:30px;" >  OR</b>  <a href='buy_now.php?buy_it=$item_id'> Master Card </a>  
 -->
 
 <b style="margin-right:30px;margin-left:30px;" > <!-- OR</b>  <a href='#'> Master Card </a>  -->
 
  </td>
  
  
  
  </tr>
 
  </th>

 <tr>
   

  <td>
  <input type="text" required="required" name="c_name" placeholder="Your name" />
  </td>
  
  </tr>
  <tr>
  
   <td>
    <input type="text" required="required" name="c_address" placeholder="Your address " />
  </td>
  
  
  </tr>
  <tr>
  
  <td>
    <input type="text" required="required" name="email" placeholder="Email "  />
  </td>
  

 </tr>

 
  
  </table>
 
  </form>
 
 
  
  
  </div>
  
  
  
 
 <?php 
    if(isset($_POST['submit']) and $_POST['submit']=="buy it now"){
    
    
    
     $id_i=$_POST['id_item_a'];
     $address=$_POST['c_address'];
     $phone=$_POST['c_phone'];
     $name=$_POST['c_name'];
     $email=$_POST['email'];
     
     include'infoConnect.php';
      
      $con=mysqli_connect($host,$user,$password,$dataname);
  
     $date_t=date("Y-m-d");
    // $time_t=time("h:i:s");
    
    
    //enc
      
      $omtokiss = '3LifeJosephHodaOm';
$method = 'aes-256-cbc';

// Must be exact 32 chars (256 bit)
$omtokiss = substr(hash('sha256', $omtokiss, true), 0, 32);
//echo "Password:" . $password . "\n";

// IV must be exact 16 chars (128 bit)
$iv = chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0);

// av3DYGLkwBsErphcyYp+imUW4QKs19hUnFyyYcXwURU=
$enc_address = base64_encode(openssl_encrypt($address, $method, $omtokiss, OPENSSL_RAW_DATA, $iv));

$enc_phon = base64_encode(openssl_encrypt($phone, $method, $omtokiss, OPENSSL_RAW_DATA, $iv));

$enc_name = base64_encode(openssl_encrypt($name, $method, $omtokiss, OPENSSL_RAW_DATA, $iv));

$enc_email = base64_encode(openssl_encrypt($email, $method, $omtokiss, OPENSSL_RAW_DATA, $iv));

      
      //enc end
      
    
    
    
    
      $s_insert=mysqli_query($con,"insert into buy_n(item_id,address,phone,email_customer,nickname,b_date) values('$id_i','$enc_address','$enc_phone','$enc_email','$enc_name','$date_t')");
      
      if($s_insert){
      
      
      //
      
      
    
      
$to =$_POST['email'];
$subject = "we will call you ";

$message = "we hope to see you again...don't worry about delivery , we will care about it";



// More headers
$headers = 'From: joxtime.com';


mail($to,$subject,$message,$headers);

    
     // to admin
     
     
$to ="josephmorcos6@gmail.com";
$subject = "there is product has sold";

$message = "check your website  ";



// More headers
$headers = 'From: joxtime.com';


mail($to,$subject,$message,$headers);

       
     
     
     
     
      
      
      
      
      
      
      //
      
        echo '<script> window.open("thanks.php","_self")</script>' ;
      
      
      
      }else{
      
      
      echo"<h1>check your network connection</h1>";
      
      }
      
     
     
     $ch_stat="sold";
     $s_update=mysqli_query($con,"update items_file_jo_lhoda set status='$ch_stat' where id_item='$id_i'");
     
     
     
     
     
     
     
     
      }
      
      ?>
      
      
      
     
     

        <footer>

             <p class="footer_gallary_p">Copyright reserved - Joseph A Mork</p>
            
        </footer>

    </body>
</html>