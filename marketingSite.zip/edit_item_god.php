<?php
session_start();
if(!isset($_SESSION['en_email'])){
    include 'god.php';
    die();
}

?>

<html>
    <head>
        <script type='text/javascript'>
            function preview_image(event)
            {
                var reader = new FileReader();
                reader.onload = function ()
                {
                    var output = document.getElementById('output_image');
                    output.src = reader.result;
                };
                reader.readAsDataURL(event.target.files[0]);
            }
            
             function preview_image2(event)
            {
                var reader = new FileReader();
                reader.onload = function ()
                {
                    var output = document.getElementById('output_image2');
                    output.src = reader.result;
                };
                reader.readAsDataURL(event.target.files[0]);
            }
            
             function preview_image3(event)
            {
                var reader = new FileReader();
                reader.onload = function ()
                {
                    var output = document.getElementById('output_image3');
                    output.src = reader.result;
                };
                reader.readAsDataURL(event.target.files[0]);
            }
            
            
        </script> 
        <meta charset="UTF-8">
        <link rel="stylesheet" href="Resource/CssHomePro/Home_Programmer_css.css" type="text/css"/>
        <link rel="stylesheet" href="Resource/CssHomePro/cssAlljob.css" type="text/css"/>
        <link rel="stylesheet" href="Resource/css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="Resource/css/bootstrap.css" type="text/css">
         <link rel="stylesheet" href="Resource/css/styleJO.css">
          <link rel="stylesheet" href="Resource/css/jsJOSEPH.css">
          <link rel="stylesheet" href="Resource/CssHomePro/view_images.css" type="text/css"/>
        <title> edit items </title>
    </head>
    <body>
        
  
        
        <a class="profile" href="All_items_god"> <h4>site item's </h4></a>
         <h6 style="margin-left: 50%; color: #0062cc;"> <?php echo $_SESSION['en_email'];      ?>    </h6>
  
        

        
       
        <header>
      
        </header> 
       
        
        
         <form method="POST" enctype="multipart/form-data" action="edit_item_god">
            <table>
                <tr>
                <td>
              
                <img src="Resource/images/logo_n.png" id="output_image" width="150px" height="150px" alt="a7a where the fucking photo" />
                
                </td>
                          
                            <td>
                            
                            <img src="Resource/images/logo_n.png" id="output_image2" width="150px" height="150px" alt="a7a where the fucking photo" />
                        
                         </td>
                     
                     <td>
                            
                            <img src="Resource/images/logo_n.png" id="output_image3" width="150px" height="150px" alt="a7a where the fucking photo" />
                        
                         </td>
                         
                        
                     
                </tr>
                 <tr>
                     <td> <input  type="file" name="image" accept="image/*" onchange="preview_image(event)" /> </td>
                     
                     <td> <input  type="file" name="image2" accept="image/*" onchange="preview_image2(event)" /> </td>
                     
                     <td> <input  type="file" name="image3" accept="image/*" onchange="preview_image3(event)" /> </td>
                     </tr>
                     <th>
                     <tr>
                   
                     <td>  <input class="btn-primary" type="submit" name="submit" value="Update images"  /> </td>
                </tr>
                </th>
            </table>
                
             
                
               
            <?php  
       
         if(isset($_GET['id'])){
          include 'infoConnect.php';
        $con=mysqli_connect($host,$user,$password,$dataname);
       
        
        $id_item=$_GET['id'];
        
        $result=  mysqli_query($con,"SELECT * FROM items_file_jo_lhoda WHERE id_item='$id_item'");
        
        
                        while($row = mysqli_fetch_assoc($result))  
                {  
                   ?>

                
                
               <input type="text" readonly="true" name="id_n" value=" <?php   echo"$row[id_item]"; ?>" />
            <table>
                 <tr>
                     <td> <input  type="text" name="name" value="<?php echo "$row[item_name]"; ?>" /> </td>
                     <td> <input  type="text" name="age" value="<?php echo "$row[age]"; ?>" /> </td>  
                     <td> <input  type="text" name="price" value=" <?php echo "$row[price]";  ?>" /> </td>
                       <td> <select  name="video">
                       <option>antika type</option>
                       <option>gramophone</option>
                       <option>telephone</option>
                       <option>camera</option>
                       <option>light unit</option>
                       <option>Books</option>
                       <option>furniture</option>
                       <option>coins</option>
                       <option>watches</option>
                       <option>panting</option>
                       <option>tools</option>
                       </select>  </td>
                      
                       
                </tr>
                
                <tr>
                     <td> <input  type="text" readonly="true" name="store_address" placeholder="store address" value="<?php echo "$row[store_address]"; ?>"/> </td>
                     
                     <td> <input  type="text" readonly="true" name="store_phone" placeholder="store phone" value="<?php echo "$row[store_phone]"; ?>"/> </td>
                     <td> <input  type="text" readonly="true" name="email" placeholder="E-mail" value="<?php echo "$row[email]"; ?>"/> </td>
                     <td> <input  type="text" name="information" value="<?php echo "$row[information]"; ?>" /> </td>  
                     <td>  <input class="btn-primary" type="submit" name="submit" value="Update info"  /> </td>
                </tr>
                
                
          </table>
          
          
        
            
          
          
          
          
            </form>
            
         
                 
                 
                 
                 
               
                 
            
            
                      
            <div class="slideshow-container">

<div class="mySlides">
  <div class="numbertext">1 / 3</div>
  <?php echo'<img src="data:image/jpeg;base64,'.base64_encode($row['image_file']).'"style="width:100%" >' ?>
  <div class="text">Caption Text</div>
</div>

<div class="mySlides">
  <div class="numbertext">2 / 3</div>
  <?php echo'<img src="data:image/jpeg;base64,'.base64_encode($row['image_file2']).'"style="width:100%" >' ?>
  <div class="text">Caption Two</div>
</div>

<div class="mySlides">
  <div class="numbertext">3 / 3</div>
 <?php echo'<img src="data:image/jpeg;base64,'.base64_encode($row['image_file3']).'"style="width:100%" >' ?>
  <div class="text">Caption Three</div>
</div>

<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
<a class="next" onclick="plusSlides(1)">&#10095;</a>

</div>
<br>

<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span> 
  <span class="dot" onclick="currentSlide(2)"></span> 
  <span class="dot" onclick="currentSlide(3)"></span> 
</div>







    <?php
                     
                }
                 
                  }

                  ?>
                 












<script>
var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}
</script>

            
            
       
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
              
          <?php
                 if(isset($_POST['submit']) and $_POST['submit']=="Update info"){
                 
          include 'infoConnect.php';
       $con=mysqli_connect($host,$user,$password,$dataname);
        
            
         // basic file info
         $email=$_SESSION['email'];
        $name=$_POST['name'];
        $store_phone=$_POST['store_phone'];
        $store_address=$_POST['store_address'];
        $age=$_POST['age'];
        $price=$_POST['price'];
        $video=$_POST['video'];
        $price=$_POST['price'];
        $information=$_POST['information'];
        $stat="not yet";

        
               
            
            $id=$_POST['id_n'];
            
            $mysqli=mysqli_query($con,"update items_file_jo_lhoda set item_name='$name',age='$age',price='$price',store_address='$store_address',store_phone='$store_phone',video_link='$video',email='$email',information='$information',status='$stat' where id_item='$id'");
                    
                 
    
            if($mysqli){
        
                echo '<script>alert(".....Saved.....")</script> ';
                echo '<script> window.open("All_items_god","_self")</script>' ;
         
            }else{
                
                echo '<h2>call 01023257069</h2>'. mysqli_error();
                
            }    
           
          
          }
          ?>
            
            
      
      
      
      
      
      <?php
                 if(isset($_POST['submit']) and $_POST['submit']=="Update images"){
                 
          include 'infoConnect.php';
       $con=mysqli_connect($host,$user,$password,$dataname);
        
            
         
        $stat="not yet";

        //
            $pdf = addslashes(file_get_contents($_FILES['image']['tmp_name']));
            
            $namepdf = addslashes($_FILES['inputname']['name']);   
            
            $image2 = addslashes(file_get_contents($_FILES['image2']['tmp_name']));
            
            $imagename2 = addslashes($_FILES['inputname']['name']);   
            
            $image3 = addslashes(file_get_contents($_FILES['image3']['tmp_name']));
            
            $imagename3 = addslashes($_FILES['inputname']['name']);            
            
               
            
            $id=$_POST['id_n'];
            
            $mysqli=mysqli_query($con,"update items_file_jo_lhoda set image_name='$namepdf',image_file='$pdf',image_file2='$image2',image_file3='$image3',status='$stat' where id_item='$id'");
                    
                 
    
            if($mysqli){
        
                echo '<script>alert(".....Saved.....")</script> ';
                echo '<script> window.open("your_items.php","_self")</script>' ;
         
            }else{
                
                echo '<h2>call 01149239042</h2>'. mysqli_error();
                
            }    
           
          
          }
          ?>
            
            
      
      
      
      
      
      
      
      
      
      
      
            
              <footer>

             <p class="footer_gallary_p">Copyright reserved - Joseph A Mork</p>
            
        </footer>

    </body>
</html>
