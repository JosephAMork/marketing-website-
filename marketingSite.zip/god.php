<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->



<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="Resource/CssHomePro/Home_Programmer_css.css" type="text/css"/>
        <link rel="stylesheet" href="Resource/CssHomePro/cssAlljob.css" type="text/css"/>
        <link rel="stylesheet" href="Resource/css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="Resource/css/bootstrap.css" type="text/css">
         <link rel="stylesheet" href="Resource/css/styleJO.css">
         <link rel="stylesheet" href="Resource/CssHomePro/login_register.css" type="text/css"/>
        <title> ll </title>
    </head>
    <body>
         <h1> <img class="kk" src="Resource/images/antika.png" width="80%" height="200" alt="logo"/> </h1>
     
      <?php
      
      
      if(isset($_POST['submit']) and $_POST['submit']=="Login"){
      
      
      include 'infoConnect.php';
       $con=mysqli_connect($host,$user,$password,$dataname);
        
  
      $email=$_POST['email'];
      $ppass=$_POST['pin'];
      
     
           
        
        
          
      
      
      $sql_s=  mysqli_query($con,"SELECT * FROM god WHERE email='$email' AND pwd='$ppass'");

      if(mysqli_num_rows($sql_s)>0){
          
          session_start();
          $_SESSION['en_email']=$email;
          
          header('Location:god_site');
          
      }else{
          
          echo '<h2>Who Are your !</h2>';
      }
    
      }
      
      ?>
      
      
      
          

<button onclick="document.getElementById('id01').style.display='block'" style="width:200px;margin-left:40%;border-radius:5px;">Login</button>

<div id="id01" class="modal">
  
  <form class="modal-content animate" action="god" method="POST">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
      <img src="Resource/images/user.png" alt="logo" height="150" width="150">
    </div>

    <div class="container">
      <label for="uname"><b>Email</b></label>
      <input type="text" placeholder="your Email" name="email" required>

      <label for="psw"><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="pin" required>
        
      <button type="submit" name="submit" value="Login">Login</button>
      <label>
        <input type="checkbox" checked="checked" name="remember"> Remember me
      </label>
    </div>

    <div class="container" style="background-color:#f1f1f1">
      <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
      <span class="psw">Forgot <a href="error_page.php">password?</a></span>
    </div>
  </form>
</div>

<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>

        
        
        
        
        
        
        
        
        
     <div class="clear"></div>
      
      
        
        
     
        
        
        
        
        <footer>

            <p class="footer_gallary_p" style="color: #0069d9;">Copyright reserved - Joseph A Mork</p>
            
        </footer>

        
    </body>
</html>
