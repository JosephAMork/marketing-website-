<?php

$host="localhost";
$user="jo0";
$password="joseph00";
$dataname="findjoseph"


?>
