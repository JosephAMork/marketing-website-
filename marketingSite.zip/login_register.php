<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->



<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="Resource/CssHomePro/Home_Programmer_css.css" type="text/css"/>
        <link rel="stylesheet" href="Resource/CssHomePro/cssAlljob.css" type="text/css"/>
        <link rel="stylesheet" href="Resource/css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="Resource/css/bootstrap.css" type="text/css">
         <link rel="stylesheet" href="Resource/css/styleJO.css">
         <link rel="stylesheet" href="Resource/CssHomePro/login_register.css" type="text/css"/>
        <title>Login Register </title>
    </head>
    <body>
         <h1> <img class="kk" src="Resource/images/antika.png" width="80%" height="200" alt="logo"/> </h1>
     
     
      <div id="google_translate_element"></div>

 <script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

     
     
      <?php
      
      
      if(isset($_POST['submit']) and $_POST['submit']=="Login"){
      
      
      include 'infoConnect.php';
       $con=mysqli_connect($host,$user,$password,$dataname);
        
  
      $email=$_POST['email'];
      $ppass=$_POST['pin'];
      
      // encrypt
      
      
   
      
      
      
      $check=  mysqli_query($con,"SELECT email from pfirstseeinday where email='$email'");
      if(mysqli_num_rows($check)>0){
          
          echo '<h1>Email exist</h1>';
          
          ?>
        <a href="recoverPass.php">Forget Your Password</a>
              <?php 
        
        
          
      }
      
      $sql_s=  mysqli_query($con,"SELECT * FROM pfirstseeinday WHERE email='$email' AND pin='$ppass'");

      if(mysqli_num_rows($sql_s)>0){
          
          session_start();
          $_SESSION['email']=$email;
          
          header('Location:intro_admin.php');
          
      }else{
          
          echo '<h2>Besure from your email and password</h2>';
      }
    
      }
      
      ?>
      
      
      
          

<button onclick="document.getElementById('id01').style.display='block'" style="width:200px;margin-left:40%;border-radius:5px;">Login</button>

<div id="id01" class="modal">
  
  <form class="modal-content animate" action="login_register" method="POST">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
      <img src="Resource/images/user.png" alt="logo" height="150" width="150">
    </div>

    <div class="container">
      <label for="uname"><b>Email</b></label>
      <input type="text" placeholder="your Email" name="email" required>

      <label for="psw"><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="pin" required>
        
      <button type="submit" name="submit" value="Login">Login</button>
      <label>
        <input type="checkbox" checked="checked" name="remember"> Remember me
      </label>
    </div>

    <div class="container" style="background-color:#f1f1f1">
      <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
      <span class="psw">Forgot <a href="error_page.php">password?</a></span>
    </div>
  </form>
</div>

<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>

        
        
        
        
        
        
        
        
        
        <?php 
        
        if(isset($_POST['submit']) and $_POST['submit']=="Register"){
        
      include 'infoConnect.php';
      $con=mysqli_connect($host,$user,$password,$dataname);
     
      
      $email_r=$_POST['email'];
      $phone=$_POST['phone'];
      $address=$_POST['address'];
      $pin_r=$_POST['pin_register'];
      
      //enc
      
      $omtokiss = '3LifeJosephHodaOm';
$method = 'aes-256-cbc';

// Must be exact 32 chars (256 bit)
$omtokiss = substr(hash('sha256', $omtokiss, true), 0, 32);
//echo "Password:" . $password . "\n";

// IV must be exact 16 chars (128 bit)
$iv = chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0);

// av3DYGLkwBsErphcyYp+imUW4QKs19hUnFyyYcXwURU=
$enc_email_r = base64_encode(openssl_encrypt($email_r, $method, $omtokiss, OPENSSL_RAW_DATA, $iv));

$enc_phone = base64_encode(openssl_encrypt($phone, $method, $omtokiss, OPENSSL_RAW_DATA, $iv));

$enc_address = base64_encode(openssl_encrypt($address, $method, $omtokiss, OPENSSL_RAW_DATA, $iv));

$enc_pan_r = base64_encode(openssl_encrypt($pin_r, $method, $omtokiss, OPENSSL_RAW_DATA, $iv));

      
      //enc end
      
      $check_reg=  mysqli_query($con,"SELECT email from pfirstseeinday WHERE email='$enc_email_r'");
      if(mysqli_num_rows($check_reg)>0){
       ?>
        <h5> Email Exist  </h5> 
        <a style="margin-left: 40px;" href="recoverPass.php">Forget Your Password</a>
        
         <?php 
      }else{
      
      $sql_i=  mysqli_query($con,"INSERT INTO pfirstseeinday (email,phone,store_address,pin)VALUES('$enc_email_r','$enc_phone','$enc_address','$enc_pan_r')");
      
      if($sql_i){
          
          $birth="1000-01-01";
         $pro= mysqli_query($con,"INSERT INTO items_file_jo_lhoda (item_name,age,price,store_address,store_phone,video_link,email,information,image_name,image_file)"
                 ."values('','','','$enc_address','$enc_phone','','$enc_email_r','','','','')");
         
          
          session_start();
          $_SESSION['email']=$email_r;
          
          header('Location:addnewitem');
         
      }else{
          
          echo '<h5> What you Doing ? </h5>';
      }
        
      }
        }
        
        ?>
       
     <div class="clear"></div>
      
        <div class="contents">
   
            <form style="margin-left: 10%;" action="login_register" method="post">
                <h2 style="color: #D8D8D8;margin-bottom: 35px;margin-left: 35%;">Register</h2>
                   
                    <input required="required" style="margin-bottom: 10px;" name="phone" class="input-group-lg" type="text" placeholder=" mobile number "/></br>
                    <input required="required" style="margin-bottom: 10px;" name="address" class="input-group-lg" type="text" placeholder="Store Address"/></br>                   
                    <input required="required" style="margin-bottom: 10px;" name="email" class="input-group-lg" type="text" placeholder="email please "/></br>
                    <input required="required" style="margin-bottom: 10px;" name="pin_register" class="input-group-lg" type="password" placeholder="Your Password"/></br>
                              
                    <input class="btn-primary" style="margin-left: 35%;margin-top: 30px;width:130px;height:50px;border-radius:5px;" type="submit" name="submit"  value="Register"/>
                    
                    
        </form>
        
        </div>
        
        
        
        
     
        
        
        
        
        <footer>

            <p class="footer_gallary_p" style="color: #0069d9;">Copyright reserved - Joseph A Mork</p>
            
        </footer>

        
    </body>
</html>
