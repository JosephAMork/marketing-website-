<?php
session_start();
if(!isset($_SESSION['en_email'])){
    include 'god.php';
    die();
}

?>

<html>
    <head>
        
        <meta charset="UTF-8">
        <link rel="stylesheet" href="Resource/CssHomePro/Home_Programmer_css.css" type="text/css"/>
        <link rel="stylesheet" href="Resource/CssHomePro/cssAlljob.css" type="text/css"/>
        <link rel="stylesheet" href="Resource/css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="Resource/css/bootstrap.css" type="text/css">
         <link rel="stylesheet" href="Resource/css/styleJO.css">
          <link rel="stylesheet" href="Resource/css/jsJOSEPH.css">
        <title>  </title>
    </head>
    <body>
        
  
        
        <a class="profile" href="god_site.php"> <h4>Back to Home</h4></a>
     
           
        <header>
       
        </header> 
       
            
            
            
                
            
            
           
            
           
            
            <?php   
            
            
            include 'infoConnect.php';
            
            
            $con=mysqli_connect($host,$user,$password,$dataname);
            
          
         
            $get_data_table=mysqli_query($con,"select * from sold_items ");
            
            if(mysqli_num_rows($get_data_table)>0){
            
            
            while($row=mysqli_fetch_assoc($get_data_table)){
            
             $address=$row['address'];
             $phone=$row['phone'];
             $email_s=$row['email_customer'];
             $nick=$row['nickname'];
             //
             
            $id=$row['item_id'];
            $item_n=$row['item_name'];
            $price=$row['price'];
            $s_phone=$row['store_phone'];
            $time=$row['b_time'];
   
   
   
   
    
   //enc
             
             
$omtokiss = '3LifeJosephHodaOm';
$method = 'aes-256-cbc';

// Must be exact 32 chars (256 bit)
$omtokiss = substr(hash('sha256', $omtokiss, true), 0, 32);
//echo "Password:" . $password . "\n";

// IV must be exact 16 chars (128 bit)
$iv = chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0);


$de_address = openssl_decrypt(base64_decode($address), $method, $omtokiss, OPENSSL_RAW_DATA, $iv);

$de_phone = openssl_decrypt(base64_decode($phone), $method, $omtokiss, OPENSSL_RAW_DATA, $iv);

$de_email = openssl_decrypt(base64_decode($email_s), $method, $omtokiss, OPENSSL_RAW_DATA, $iv);

$de_nick = openssl_decrypt(base64_decode($nick), $method, $omtokiss, OPENSSL_RAW_DATA, $iv);
   
        //end enc

   
   
   
   
   
   
            
           ?>
            
            
            
            
            
            
            <table>
            <th>
            
            <tr>
            
            <td>
           <!-- <a href="edit_item.php?id=<?php echo $id ?>"> --> <?php   echo"$id";  ?>  <!--  </a> --> 
            
            </td>
      
            
            <td>
          <b> phone:</b> <?php   echo"$de_phone";  ?>   
            
            </td>
            
            <td>
           <b> email:</b> <?php   echo"$de_email";  ?>  
            </td>
           
            <td>
            <b> Customer Name:</b> <?php   echo"$de_nick";  ?>  
             
            </td>
            
            
            <td>
            <b> address:</b> <?php   echo"$de_address";  ?>   
           
            
            </td>
            </tr>
            
            <tr>
            
            <td>
             <b> Item :</b><?php   echo"$item_n";  ?>  
            
            </td>
            
            
            <td>
             <b> Price:</b><?php   echo"$price";  ?>  $ 
            
            </td>
            
            
            <td>
            <b> Time :</b><?php   echo"$time";  ?>  
            </td>
            
            <td>
            
            <?php echo'<img src="data:image/jpeg;base64,'.base64_encode($row['image_file']).' " height="100" width="100" />';   ?>
            
            </td>
            
            
            </tr>
             </th>
            
            </table>
            
            
            
            
            
            
            <?php
            
            
            }
            
         
            }
            
            
            
            
            
            
           ?>
            
            
            
            
            
            
            
            
            
            
            
              <footer>

             <p class="footer_gallary_p">Copyright reserved - Joseph A Mork</p>
            
        </footer>

    </body>
</html>
