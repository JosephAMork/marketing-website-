<?php

include'infoConnect.php';
$con=mysqli_connect($host,$user,$password,'findjoseph');

if(mysqli_connect_error($con)){
	
	echo "Failed to connect to Database".mysqli_connect_error();
	
	}
	
	$name=$_post['name'];
	$sql_data="SELECT * FROM findjoseph WHERE email LIKE '%$name%'";


$query=mysqli_query($con,$sql_data);

if($query){
	
	
	while($row=mysqli_fetch_array($query)){
		
		$data[]=$row;
		
		
		}
	print(json_encode($data));
	
	}else{
		
		echo "No Data __|__ ";
		}
		
		mysqli_close($con);

?>
