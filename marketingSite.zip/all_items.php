<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="Resource/CssHomePro/Home_Programmer_css.css" type="text/css"/>
        <link rel="stylesheet" href="Resource/CssHomePro/cssAlljob.css" type="text/css"/>
        <link rel="stylesheet" href="Resource/css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="Resource/css/bootstrap.css" type="text/css">
         <link rel="stylesheet" href="Resource/css/styleJO.css">
         <link rel="stylesheet" href="Resource/css/jsJOSEPH.css">
        <title> Items </title>
        
        <script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

        
    </head>
    <body>
        
         <h1> <img class="kk" src="Resource/images/logosite.png" width="80%" height="200" alt="logo"/> </h1>
     
        <!--
        <header>
        <div class="site">
        <h1> Find Programmer  </h1>
        </div>
        </header> 
       -->
        
        <div class="contents_gallary">
             <ul>
                 <li style="margin-left: 10%"><a href="gramophone.php">Gramophone</a></li>
                <li><a href="telephone.php">Telephone</a></li>
                <li><a href="camera.php">Camera</a></li>
                 <li><a href="light.php">Lamps</a></li>
                 <li><a href="#">|</a></li>
                 <li><a href="books.php"> Books</a></li>
                 <li><a href="woods.php">Furniture</a></li>
                 <li><a href="coins.php">Coins</a></li>
                 <li><a href="watches.php">watches</a></li>
                 <li><a href="panting.php">Painting</a></li>
                 <li><a href="tools.php">Tools</a></li>
                

            </ul>
         </div>
  
  
  <div id="google_translate_element"></div>
  
       <form action="all_items.php" method="POST">
      <input required="required" style="margin-top: 10px;" class="searchpro" size="40" type="text" name="search_text" placeholder="  Search here " />
            <input class="btn-danger" type="submit" name="submit" value="Search" />
            <a style="margin-left: 40%;font-size: 20px;" href="all_items.php">Reload</a>
           
            <ul>          
                  <?php
                  
                  if(isset($_POST['submit']) and $_POST['submit']=="Search"){
                     
         include 'infoConnect.php';
        
        $con=mysqli_connect($host,$user,$password,$dataname);
        
        $value=$_POST['search_text'];
        
        $result=  mysqli_query($con,"select * from items_file_jo_lhoda where item_name like '%$value%'");
        
        if(mysqli_num_rows($result)>0){
                        while($row = mysqli_fetch_assoc($result))  
                {  
     
           ?>          
                                  
                     <li style="margin-right: 10px; margin-bottom: 10px;">
                
<div class="card">
    <?php
               echo ' <img src="data:image/jpeg;base64,'.base64_encode($row['image_file'] ).'" height="250" width="250" class="img-thumnail" /> ';
    ?>
       
    <h3 style="color: #007bff;"><?php echo $row['item_name'];  ?></h3>
    <p style="color: #bd2130;">price :<?php echo $row['price'];    ?> </p>
  <p style="color: #007bff;"> Age :<?php echo $row['age'];    ?> </p>
  <div style="margin: 24px 0;">
      
      <h6 style="color: #007bff;"><?php echo $row['store_address'];  ?></h6> 
 </div>
  <p><button><a href="google-play.com/FindProgrammer">Get it</a></button></p>
 
 
</div>
        
            </li>
            
           <?php
                     
                     
                     
                }
                
        }
                  
        
                      } else{

?>

                    
       <?php  
       
       
         include 'infoConnect.php';
        
        $con=mysqli_connect($host,$user,$password,$dataname);
           
        $result=  mysqli_query($con,"select * from items_file_jo_lhoda ");
        
        if(mysqli_num_rows($result)>0){
                        while($row = mysqli_fetch_assoc($result))  
                {  
                     
                
           ?>                       
                     <li style="margin-right: 10px; margin-bottom: 10px;">
                
<div class="card">
    <?php
               echo ' <img src="data:image/jpeg;base64,'.base64_encode($row['image_file'] ).'" height="250" width="250" class="img-thumnail" /> ';
    ?>
       
    <h3 style="color: #007bff;"><?php echo $row['item_name'];  ?></h3>
    <p style="color: #bd2130;"> price : <?php echo $row['price'];    ?> </p>
  <p style="color: #007bff;"> Age : <?php echo $row['age'];    ?> </p>
  <div style="margin: 24px 0;">
      
      <h6 style="color: #007bff;"><?php echo $row['store_address'];  ?></h6> 
 </div>
  <p><button><a href="google-play.com/FindProgrammer">Get it</a></button></p>

</div>      
            </li>
            
           <?php
       
                }
                
        }
                }             
                  
?>
          
             </ul>
                        
  </form>

        <footer>

             <p class="footer_gallary_p">Copyright reserved - Joseph A Mork</p>
            
        </footer>

    </body>
</html>