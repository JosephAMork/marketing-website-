<?php


session_start();
if(!isset($_SESSION['email'])){
    include 'login_register';
    die();
    
    
   
}

?>

<html>
    <head>
    
        <script type='text/javascript'>
        
            function preview_image(event)
            {
                var reader = new FileReader();
                reader.onload = function ()
                {
                    var output = document.getElementById('output_image');
                    output.src = reader.result;
                };
                reader.readAsDataURL(event.target.files[0]);
            }
            
            function preview_image2(event)
            {
                var reader = new FileReader();
                reader.onload = function ()
                {
                    var output = document.getElementById('output_image2');
                    output.src = reader.result;
                };
                reader.readAsDataURL(event.target.files[0]);
            }
            
            function preview_image3(event)
            {
                var reader = new FileReader();
                reader.onload = function ()
                {
                    var output = document.getElementById('output_image3');
                    output.src = reader.result;
                };
                reader.readAsDataURL(event.target.files[0]);
            }
            
            
            
          
        </script> 
        
        <meta charset="UTF-8">
        <link rel="stylesheet" href="Resource/CssHomePro/Home_Programmer_css.css" type="text/css"/>
        <link rel="stylesheet" href="Resource/CssHomePro/cssAlljob.css" type="text/css"/>
        <link rel="stylesheet" href="Resource/css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="Resource/css/bootstrap.css" type="text/css">
         <link rel="stylesheet" href="Resource/css/styleJO.css">
          <link rel="stylesheet" href="Resource/css/jsJOSEPH.css">
          
         
          
        <title> Upload product </title>
    </head>
    <body>
        <div id="google_translate_element"></div>


  
        
        <a class="profile" href="your_items"> <h4>Your products </h4></a>
         <h6 style="margin-left: 50%; color: #0062cc;"> <?php echo $_SESSION['email'];      ?>    </h6>
  
         <?php  
         include 'infoConnect.php';
        
        $con=mysqli_connect($host,$user,$password,$dataname);
       
        
        $email=$_SESSION['email'];
        $result=  mysqli_query($con,"select * from pro_data where pro_email='$email' ");
        
        if(mysqli_num_rows($result)>0){
                        while($row = mysqli_fetch_assoc($result))  
                {  
                            ?>
         
         <h6 style="margin-left: 50%;">
         <?php            echo '   
                                    <img src="data:image/jpeg;base64,'.base64_encode($row['image_file'] ).'" height="60" width="60"  class="img-thumnail" />  
                               
                     ';
         
         ?>
         </h6>
         <?php
                }
                
        }
                

?>

        
       
        <header>
       <!--
            <div class="site">
        <h1> Find Programmer  </h1>
     -->
      
        </div>
        </header> 
       
         <form method="POST" enctype="multipart/form-data" action="addnewitem">
            <table>
                <tr>
                <td>
              
                <img src="Resource/images/logo_n.png" id="output_image" width="150px" height="150px" alt="a7a where the fucking photo" />
                
                </td>
                          
                            <td>
                            
                            <img src="Resource/images/logo_n.png" id="output_image2" width="150px" height="150px" alt="a7a where the fucking photo" />
                        
                         </td>
                     
                     <td>
                            
                            <img src="Resource/images/logo_n.png" id="output_image3" width="150px" height="150px" alt="a7a where the fucking photo" />
                        
                         </td>
                         
                         
                     
                </tr>
                 <tr>
                     <td> <input  type="file" name="image" accept="image/*" onchange="preview_image(event)" /> </td>
                     
                     <td> <input  type="file" name="image2" accept="image/*" onchange="preview_image2(event)" /> </td>
                     
                     <td> <input  type="file" name="image3" accept="image/*" onchange="preview_image3(event)" /> </td>
                     
            
                     
                </tr>
            </table>
                
               
                
                 <!--    get data from DB    -->
            <?php  
         include 'infoConnect.php';
        
        $con=mysqli_connect($host,$user,$password,$dataname);
       
        
        $email=$_SESSION['email'];
        
        //decrypt
        
        $omtokiss = '3LifeJosephHodaOm';
$method = 'aes-256-cbc';

// Must be exact 32 chars (256 bit)
$omtokiss = substr(hash('sha256', $omtokiss, true), 0, 32);
//echo "Password:" . $password . "\n";

// IV must be exact 16 chars (128 bit)
$iv = chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0);



// My secret message 1234
$enc_mail = base64_encode(openssl_encrypt($email, $method, $omtokiss, OPENSSL_RAW_DATA, $iv));

        
        
        
        
        //
        
        
        $result=  mysqli_query($con,"SELECT * FROM pfirstseeinday WHERE email='$enc_mail'");
        
        
                        while($row = mysqli_fetch_assoc($result))  
                {  
                
                
                             $en_address=$row['store_address']; 
                             $en_phone=$row['phone'];
                             $en_email=$row['email'];
                             
                             
                             
                             
                             //decrypt
        
        $omtokiss = '3LifeJosephHodaOm';
$method = 'aes-256-cbc';

// Must be exact 32 chars (256 bit)
$omtokiss = substr(hash('sha256', $omtokiss, true), 0, 32);
//echo "Password:" . $password . "\n";

// IV must be exact 16 chars (128 bit)
$iv = chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0);



// My secret message 1234
$dec_mail = openssl_decrypt(base64_decode($en_email), $method, $omtokiss, OPENSSL_RAW_DATA, $iv);

$dec_phone = openssl_decrypt(base64_decode($en_phone), $method, $omtokiss, OPENSSL_RAW_DATA, $iv);

$dec_address = openssl_decrypt(base64_decode($en_address), $method, $omtokiss, OPENSSL_RAW_DATA, $iv);

        
        
        
        
        //
        
                            
                
                   ?>

                
                
                
            <table>
                 <tr>
                     <td> <input style="margin-left:30px; margin-top: 20px;" type="text" name="name" placeholder="item name" /> </td>
                     <td> <input style="margin-left:30px; margin-top: 20px;" type="text" name="age" placeholder="age" /> </td>  
                     <td> <input style="margin-left:30px; margin-top: 20px;" type="text" name="price" placeholder="Price" /> </td>
                       <td> <select style="margin-left:30px; margin-top: 20px;" name="video">
                       <option>antika type</option>
                       <option>gramophone</option>
                       <option>telephone</option>
                       <option>camera</option>
                       <option>Lamps</option>
                       <option>Books</option>
                       <option>furniture</option>
                       <option>coins</option>
                       <option>watches</option>
                       <option>painting</option>
                       <option>tools</option>
                       </select>  </td>
                   
                       
                </tr>
                
                <tr>
                     <td> <input style="margin-left:30px; margin-top: 20px;" type="text" readonly="true" name="store_address" placeholder="store address" value="<?php echo "$dec_address"; ?>"/> </td>
                     
                     <td> <input style="margin-left:30px; margin-top: 20px;" type="text" readonly="true" name="store_phone" placeholder="store phone" value="<?php echo "$dec_phone"; ?>"/> </td>
                     <td> <input style="margin-left:30px; margin-top: 20px;" type="text" readonly="true" name="email" placeholder="E-mail" value="<?php echo "$dec_mail"; ?>"/> </td>
                     <td> <input style="margin-left:30px; margin-top: 20px;" type="text" name="information" placeholder="Information" /> </td>  
                     
                     <td>  <input class="btn-primary" type="submit" name="submit" value="Save Changes" style="margin-left:50px; margin-top: 20px;" /> </td>
                </tr>
                
                
            </table> 
            
                 
                 
                   <?php
                     
                }
                 

                  ?>
                 
                 
            </form>      
            <?php
           
            
             if(isset($_POST['submit']) and $_POST['submit']=="Save Changes"){
      
      
      include 'infoConnect.php';
       $con=mysqli_connect($host,$user,$password,$dataname);
        
            
         // basic file info
         $email=$_SESSION['email'];
        $name=$_POST['name'];
        $store_phone=$_POST['store_phone'];
        $store_address=$_POST['store_address'];
        $age=$_POST['age'];
        $price=$_POST['price'];
        $video=$_POST['video'];
        $price=$_POST['price'];
        $information=$_POST['information'];
        $stat="not yet";

        //
            $pdf = addslashes(file_get_contents($_FILES['image']['tmp_name']));
            
            $namepdf = addslashes($_FILES['inputname']['name']);   
            
            $image2 = addslashes(file_get_contents($_FILES['image2']['tmp_name']));
            
            $imagename2 = addslashes($_FILES['inputname']['name']);   
            
            $image3 = addslashes(file_get_contents($_FILES['image3']['tmp_name']));
            
            $imagename3 = addslashes($_FILES['inputname']['name']);            
            
             
            
            $mysqli=mysqli_query($con,"insert into  items_file_jo_lhoda(item_name,age,price,store_address,store_phone,video_link,email,information,image_name,image_file,image_file2,image_file3,status)"
                    . "values('$name','$age','$price','$store_address','$store_phone','$video','$email','$information','$namepdf','$pdf','$image2','$image3','$stat')");
                 
    
            if($mysqli){
        
                echo '<script>alert(".....Saved.....")</script> ';
         
            }else{
                
                echo '<h2>call 01149239042</h2>'. mysqli_error();
                
            }    
           
            		
        
        
        
        
             }
            ?>
            
           
            
            
            
            
            
            
            <!--  statistics about uploaded and downloaded files    -->
            
            <table  style="margin-top:30px; margin-left: 30px;" >
                
                <?php 
                
                include'infoConnect.php';
                
                $con=mysqli_connect($host,$user,$password,$dataname);
               
                $get_d=mysqli_query($con,"select count(id_item)as'total' from items_file_jo_lhoda ");
                if($get_d){
                while($num=mysqli_fetch_assoc($get_d)){
                ?>
                
               <th> <tr> <td>  number Of items : </td>  
               </th>
               </tr>
               <tr>
               <td>  <?php echo"$num[total]";?>  </td> 
               </tr>
                <?php
                
                }
                }
                  ?>
                
                
           
            
            </table>
            
            
            
            
              <footer>

             <p class="footer_gallary_p">Copyright reserved - Joseph A Mork</p>
            
        </footer>

    </body>
</html>
