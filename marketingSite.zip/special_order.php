<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="Resource/CssHomePro/Home_Programmer_css.css" type="text/css"/>
        <link rel="stylesheet" href="Resource/CssHomePro/cssAlljob.css" type="text/css"/>
        <link rel="stylesheet" href="Resource/css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="Resource/css/bootstrap.css" type="text/css">
         <link rel="stylesheet" href="Resource/css/styleJO.css">
         <link rel="stylesheet" href="Resource/css/jsJOSEPH.css">
       
        <title> special order </title>
        
        
        
        <style>
input[type=text], select, textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    margin-top: 6px;
    margin-bottom: 16px;
    resize: vertical;
}

input[type=submit] {
    background-color: #4CAF50;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #45a049;
}

.container {
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
}
</style>
    </head>
    <body>
       
         <h1> <img class="kk" src="Resource/images/antika.png" width="80%" height="200" alt="logo"/> </h1>
       

        <div id="google_translate_element"></div>

 <script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

         
        <header>
       
      
       
        </header> 
      
        <div class="contents_gallary">


             <ul>
                
             <li style="margin-left: 10%"><a href="gramophone.php">Gramophone</a></li>
                <li><a href="telephone.php">Telephone</a></li>
                <li><a href="camera.php">Camera</a></li>
                 <li><a href="light.php">Lamps</a></li>
               
                 <li><a href="books.php"> Books</a></li>
                 <li><a href="woods.php">Furniture</a></li>
                 <li><a href="coins.php">Coins</a></li>
                 <li><a href="watches.php">watches</a></li>
                 <li><a href="panting.php">Painting</a></li>
                 <li><a href="tools.php">Tools</a></li>
                
                


            </ul>
         </div>
  
  
  
  


<div class="container" style="margin-left:10%;">
  <form action="special_order" method="POST">
    <label for="fname">Your Email</label>
    <input type="text" id="fname" name="email_t" placeholder="Your Email..">

    <label for="lname">Phone number</label>
    <input type="text" id="lname" name="phone_t" placeholder="Your  number..">

    <label for="country">Address</label>
    <input type="text" id="lname" name="address" placeholder="Your  address">

    <label for="subject">Subject</label>
    <textarea id="subject" name="subject" placeholder="All Your wishes" style="height:200px"></textarea>

    <input type="submit" name="submit" value="Send">
  </form>
</div>

  
  <?php 
  
  
  if(isset($_POST['submit']) and $_POST['submit']==Send){
  
  include 'infoConnect.php';
  $con=mysqli_connect($host,$user,$password,$dataname);
  $email_text=$_POST['email_t'];
  $phone_text=$_POST['phone_t'];
  $address_t=$_POST['address'];
  $subject_t=$_POST['subject'];
  
  
  
   //enc
      
      $omtokiss = '3LifeJosephHodaOm';
$method = 'aes-256-cbc';

// Must be exact 32 chars (256 bit)
$omtokiss = substr(hash('sha256', $omtokiss, true), 0, 32);
//echo "Password:" . $password . "\n";

// IV must be exact 16 chars (128 bit)
$iv = chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0);

// av3DYGLkwBsErphcyYp+imUW4QKs19hUnFyyYcXwURU=
$enc_email_s = base64_encode(openssl_encrypt($email_text, $method, $omtokiss, OPENSSL_RAW_DATA, $iv));

$enc_phone_s = base64_encode(openssl_encrypt($phone_text, $method, $omtokiss, OPENSSL_RAW_DATA, $iv));

$enc_address_s = base64_encode(openssl_encrypt($address_t, $method, $omtokiss, OPENSSL_RAW_DATA, $iv));

$enc_subject_s = base64_encode(openssl_encrypt($subject_t, $method, $omtokiss, OPENSSL_RAW_DATA, $iv));

      
      //enc end
      
  
  
  
  $sql_j=mysqli_query($con,"insert into s_order(email,phone,address,subject) values('$enc_email_s','$enc_phone_s','$enc_address_s','$enc_subject_s')");
  
  if($sql_j){
  
  
      // to admin
     
     
$to ="josephmorcos6@gmail.com";
$subject = "there is ask for special items";

$message = "check your website  ";



// More headers
$headers = 'From: joxtime.com';


mail($to,$subject,$message,$headers);

       
    
  
  echo '<script> window.open("thanks.php","_self") </script>';
  
  
  }else{
  
  echo "Check your Network Connection ";
  
  }
  
  
  
  
  }
  
  
  ?>
  
  
  
  
  
  
  
      
        <footer>

             <p class="footer_gallary_p">Copyright reserved - Joseph A Mork</p>
            
        </footer>

    </body>
</html>