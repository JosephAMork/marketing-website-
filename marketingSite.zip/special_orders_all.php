<?php
session_start();
if(!isset($_SESSION['en_email'])){
    include 'god.php';
    die();
}

?>

<html>
    <head>
        
        <meta charset="UTF-8">
        <link rel="stylesheet" href="Resource/CssHomePro/Home_Programmer_css.css" type="text/css"/>
        <link rel="stylesheet" href="Resource/CssHomePro/cssAlljob.css" type="text/css"/>
        <link rel="stylesheet" href="Resource/css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="Resource/css/bootstrap.css" type="text/css">
         <link rel="stylesheet" href="Resource/css/styleJO.css">
          <link rel="stylesheet" href="Resource/css/jsJOSEPH.css">
        <title>  </title>
    </head>
    <body>
        
  
        
        <a class="profile" href="god_site.php"> <h4>Back to Home</h4></a>
     
           
        <header>
       
        </header> 
       
            
            
            
                
            
            
           
            
           
            
            <?php   
            
            
            include 'infoConnect.php';
            
            
            $con=mysqli_connect($host,$user,$password,$dataname);
            
          
         
            $get_data_table=mysqli_query($con,"select * from s_order ");
            
            if(mysqli_num_rows($get_data_table)>0){
            
            
            while($row=mysqli_fetch_assoc($get_data_table)){
            
             $emails=$row['email'];
             $phone=$row['phone'];
             $address=$row['address'];
             $subject=$row['subject'];
             $id_ss=$row['id_s'];
             
             
             
             
             
             
$omtokiss = '3LifeJosephHodaOm';
$method = 'aes-256-cbc';

// Must be exact 32 chars (256 bit)
$omtokiss = substr(hash('sha256', $omtokiss, true), 0, 32);
//echo "Password:" . $password . "\n";

// IV must be exact 16 chars (128 bit)
$iv = chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0);


$de_email = openssl_decrypt(base64_decode($emails), $method, $omtokiss, OPENSSL_RAW_DATA, $iv);

$de_phone = openssl_decrypt(base64_decode($phone), $method, $omtokiss, OPENSSL_RAW_DATA, $iv);

$de_address = openssl_decrypt(base64_decode($address), $method, $omtokiss, OPENSSL_RAW_DATA, $iv);

$de_subject = openssl_decrypt(base64_decode($subject), $method, $omtokiss, OPENSSL_RAW_DATA, $iv);
   
             
             
             
             
            
           ?>
            
            
            
            
            
            
            <table>
            <th>
            
            <tr>
            
            <td>
             <?php   echo"$id_ss";  ?>  
            
            </td>
      
            
            <td>
          <b> Email:</b> <?php   echo"$de_email";  ?>   
            
            </td>
            
            <td>
           <b> phone:</b> <?php   echo"$de_phone";  ?>  
            </td>
           
            <td>
            <b> Address:</b> <?php   echo"$de_address";  ?>  
             
            </td>
            
            
            <td>
            <b> Subject:</b> <?php   echo"$de_subject";  ?>   
           
            
            </td>
            </tr>
            
           
            
            
           
             </th>
            
            </table>
            
            
            
            
            
            
            <?php
            
            
            }
            
         
            }
            
            
            
            
            
            
           ?>
            
            
            
            
            
            
            
            
            
            
            
              <footer>

             <p class="footer_gallary_p">Copyright reserved - Joseph A Mork</p>
            
        </footer>

    </body>
</html>
