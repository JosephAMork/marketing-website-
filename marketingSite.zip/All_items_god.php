<?php

session_start();
if(!isset($_SESSION['en_email'])){
    include 'god.php';
    die();
     
}

?>

<html>
    <head>
        
        <meta charset="UTF-8">
        <link rel="stylesheet" href="Resource/CssHomePro/Home_Programmer_css.css" type="text/css"/>
        <link rel="stylesheet" href="Resource/CssHomePro/cssAlljob.css" type="text/css"/>
        <link rel="stylesheet" href="Resource/css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="Resource/css/bootstrap.css" type="text/css">
         <link rel="stylesheet" href="Resource/css/styleJO.css">
          <link rel="stylesheet" href="Resource/css/jsJOSEPH.css">
        <title> Your items </title>
    </head>
    <body>
        
  
        
        <a class="profile" href="addnewitem_god"> <h4>Add new items </h4></a>
         <h6 style="margin-left: 50%; color: #0062cc;"> <?php echo $_SESSION['en_email'];      ?>    </h6>
  
         <?php  
         /*
         include 'infoConnect.php';
        
        $con=mysqli_connect($host,$user,$password,$dataname);
       
        
        $email=$_SESSION['email'];
        $result=  mysqli_query($con,"select * from pro_data where pro_email='$email' ");
        
        if(mysqli_num_rows($result)>0){
                        while($row = mysqli_fetch_assoc($result))  
                {  
                            ?>
         
         <h6 style="margin-left: 50%;">
         <?php            echo '   
                                    <img src="data:image/jpeg;base64,'.base64_encode($row['image_file'] ).'" height="60" width="60"  class="img-thumnail" />  
                               
                     ';
         
         ?>
         </h6>
         <?php
                }
                
        }
      */          

?>

        
       
        <header>
       
        </header> 
       
            
            
            
                
            
            
           
            
           
            
            <?php   
            
            
            include 'infoConnect.php';
            
            
            $con=mysqli_connect($host,$user,$password,$dataname);
          
            
            $get_data_table=mysqli_query($con,"select * from items_file_jo_lhoda");
            
            if(mysqli_num_rows($get_data_table)>0){
            
            
            while($row=mysqli_fetch_assoc($get_data_table)){
            
            
            $id=$row['id_item'];
            $item_n=$row['item_name'];
            $age=$row['age'];
            $price=$row['price'];
            $address=$row['store_address'];
            $s_phone=$row['store_phone'];
            $type=$row['video_link'];
            $email_s=$row['email'];
            $info=$row['information'];
            $status=$row['status'];
           
            
           ?>
            
            
            
            
            
            
            <table>
            <th>
            <tr>
            
            <td>
            <a href="edit_item_god?id=<?php echo $id ?>"> <?php   echo"$id";  ?>  </a> 
            
            </td>
            
            <td>
            <?php   echo"$item_n";  ?>   
            
            </td>
            
            <td>
            <?php   echo"$age";  ?>   
            
            </td>
            
            <td>
           $<?php   echo"$price";  ?>  
            </td>
            </td>
            
            
            <td>
             <?php   echo"$address";  ?>   
            
            </td>
            
            <td>
             <?php   echo"$s_phone";  ?>  
             
            </td>
            
            
            <td>
           <?php   echo"$type";  ?>  
            
            </td>
            
            
            <td>
            <?php   echo"$email_s";  ?>  
            
            </td>
            
            
            <td>
             <?php   echo"$info";  ?>   
            
            </td>
            
            
            <td>
            <?php   echo"$status";  ?>  
            </td>
            
            <td>
            
            <?php echo'<img src="data:image/jpeg;base64,'.base64_encode($row['image_file']).' " height="100" width="100" />';   ?>
            
            </td>
            
            
            </tr>
             </th>
            
            </table>
            
            
            
            
            
            
            <?php
            
            
            }
            
         
            }
            
            
            
            
            
            
           ?>
            
            
            
            
            
            
            
            
            
            
            
              <footer>

             <p class="footer_gallary_p">Copyright reserved - Joseph A Mork</p>
            
        </footer>

    </body>
</html>
